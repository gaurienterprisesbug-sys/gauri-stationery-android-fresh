# Gauri Stationery & Online Services — Android App

- App ID: `com.gauristationery.app`
- Firebase project: `gauri-stationery`
- Language: Hindi + English
- Contact / WhatsApp: 9693952498
- Address: बरवल, नरवल, काली मंदिर के समीप, बगहा-845105

## Features
- Home page, bilingual service list and rate list
- Printing, Photo, Online Services, Stationery & Gifts categories
- Call, WhatsApp and shop location buttons
- Firebase Email/Password admin login
- Admin can add, edit and delete services and prices
- Firestore listener updates customer rate list online

## Build APK without a computer
This project includes `.github/workflows/build-apk.yml`. Upload the project files to a new GitHub repository, then open **Actions** and run **Build Gauri Stationery APK**. Download the `Gauri-Stationery-debug-apk` artifact from a successful run and extract `app-debug.apk`.

Detailed Hindi instructions: `UPLOAD_FROM_ANDROID_HI.txt`.

## Firebase setup
1. Firebase Console → Authentication → Sign-in method → enable Email/Password.
2. Authentication → Users → create the admin user yourself. Use your chosen email and a strong password; never commit the password.
3. Create Firestore Database.
4. Publish the rules from `firestore.rules`.
5. `app/google-services.json` is configured for Firebase project `gauri-stationery` and Android package `com.gauristationery.app`.

## Default starter prices
- B&W Print: ₹5/page
- 36 passport photos: ₹75
- Other services show “रेट पूछें / Contact” until you set prices in Admin Panel.

## Notes
- This is the source project, not a prebuilt APK.
- Admin uses Firebase Email/Password in this version (not OTP).
- Keep Firestore rules enabled; do not make writes public.
