package com.gauristationery.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class MainActivity : Activity() {
    private val navy = Color.rgb(16, 42, 86)
    private val blue = Color.rgb(25, 91, 166)
    private val gold = Color.rgb(245, 180, 0)
    private val ink = Color.rgb(35, 45, 60)
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private var listener: ListenerRegistration? = null
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var adminMode = false

    data class ShopService(val id: String, val titleHi: String, val titleEn: String, val price: String, val category: String)
    private val fallback = listOf(
        ShopService("p1", "ब्लैक एंड व्हाइट प्रिंट", "B&W Print", "₹5 / page", "Printing"),
        ShopService("p2", "कलर प्रिंट", "Colour Print", "रेट पूछें / Contact", "Printing"),
        ShopService("p3", "पासपोर्ट साइज फोटो", "Passport Size Photo", "₹75 / 36 photos", "Photo"),
        ShopService("s1", "आधार कार्ड सेवा", "Aadhaar Services", "रेट पूछें / Contact", "Online Services"),
        ShopService("s2", "पैन कार्ड सेवा", "PAN Card Services", "रेट पूछें / Contact", "Online Services"),
        ShopService("s3", "पासपोर्ट आवेदन", "Passport Application", "रेट पूछें / Contact", "Online Services"),
        ShopService("s4", "आयुष्मान कार्ड", "Ayushman Card", "रेट पूछें / Contact", "Online Services"),
        ShopService("s5", "राशन कार्ड सेवा", "Ration Card Services", "रेट पूछें / Contact", "Online Services"),
        ShopService("s6", "जन्म प्रमाण पत्र", "Birth Certificate", "रेट पूछें / Contact", "Online Services"),
        ShopService("st1", "स्टेशनरी सामग्री", "Stationery Items", "दुकान पर उपलब्ध / In-store", "Stationery & Gifts"),
        ShopService("st2", "गिफ्ट आइटम्स", "Gift Items", "दुकान पर उपलब्ध / In-store", "Stationery & Gifts")
    )
    private var services = fallback.toMutableList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        listenForRates()
    }

    override fun onDestroy() { listener?.remove(); super.onDestroy() }

    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(246,248,252)) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(20, 22, 20, 22); setBackgroundColor(navy)
        }
        header.addView(TextView(this).apply { text = "GAURI"; textSize = 30f; setTextColor(gold); gravity = Gravity.CENTER; setTypeface(null, 1) })
        header.addView(TextView(this).apply { text = "STATIONERY & ONLINE SERVICES"; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, 1) })
        header.addView(TextView(this).apply { text = "गौरी स्टेशनरी एवं ऑनलाइन सर्विसेस"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0,5,0,0) })
        root.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,16,16,24) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun showHome() {
        adminMode = false
        base("Home")
        card("Welcome / स्वागत है", "आपकी सुविधा, हमारी प्राथमिकता\nYour trusted shop for stationery, printing and online services.")
        sectionTitle("Our Services / हमारी सेवाएँ")
        val categories = listOf("All Services / सभी सेवाएँ", "Printing", "Photo", "Online Services", "Stationery & Gifts")
        categories.forEach { category ->
            val b = button(if (category == "All Services / सभी सेवाएँ") category else categoryLabel(category), blue)
            b.setOnClickListener { showRates(if (category.startsWith("All")) null else category) }
            content.addView(b)
        }
        sectionTitle("Quick Contact / तुरंत संपर्क")
        button("WhatsApp: 9693952498", Color.rgb(25,145,85)).setOnClickListener { openWhatsApp() }.also { content.addView(it) }
        button("Call Now / अभी कॉल करें", navy).setOnClickListener { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:9693952498"))) }.also { content.addView(it) }
        button("Shop Location / दुकान का पता", blue).setOnClickListener { openMap() }.also { content.addView(it) }
        button("Admin Login / एडमिन लॉगिन", gold, ink).setOnClickListener { showAdminLogin() }.also { content.addView(it) }
        card("Shop Address / दुकान का पता", "बरवल, नरवल, काली मंदिर के समीप, बगहा-845105\nBarwal, Narwal, Near Kali Mandir, Bagaha – 845105\nMobile: 9693952498")
        TextView(this).apply { text = "© Gauri Stationery & Online Services"; gravity = Gravity.CENTER; setTextColor(Color.GRAY); textSize = 12f; setPadding(0,16,0,0) }.also { content.addView(it) }
    }

    private fun showRates(category: String?) {
        base("Rates")
        content.addView(button("← Home / वापस जाएँ", navy).apply { setOnClickListener { showHome() } })
        sectionTitle("Rates & Services / रेट लिस्ट")
        val visible = if (category == null) services else services.filter { it.category == category }
        if (visible.isEmpty()) card("No services yet", "इंटरनेट कनेक्शन होने पर रेट अपडेट दिखाई देंगे।")
        visible.forEach { service ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,14,16,14); setBackgroundColor(Color.WHITE) }
            box.addView(TextView(this).apply { text = service.titleHi; textSize = 17f; setTextColor(navy); setTypeface(null,1) })
            box.addView(TextView(this).apply { text = service.titleEn; textSize = 14f; setTextColor(ink) })
            box.addView(TextView(this).apply { text = service.price; textSize = 16f; setTextColor(Color.rgb(190,80,20)); setTypeface(null,1); setPadding(0,7,0,0) })
            content.addView(box, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 10 })
        }
        content.addView(button("WhatsApp for Details / जानकारी के लिए WhatsApp करें", Color.rgb(25,145,85)).apply { setOnClickListener { openWhatsApp() } })
    }

    private fun showAdminLogin() {
        base("Admin")
        content.addView(button("← Home", navy).apply { setOnClickListener { showHome() } })
        card("Admin Panel / एडमिन पैनल", "अपने रेट और सर्विस अपडेट करने के लिए Admin Email और Password से लॉगिन करें।")
        val email = EditText(this).apply { hint = "Admin email"; inputType = 33 }
        val pass = EditText(this).apply { hint = "Password"; inputType = 129 }
        content.addView(email); content.addView(pass)
        content.addView(button("Login / लॉगिन", blue).apply {
            setOnClickListener {
                val e = email.text.toString().trim(); val p = pass.text.toString()
                if (e.isBlank() || p.isBlank()) { toast("Email और password भरें"); return@setOnClickListener }
                auth.signInWithEmailAndPassword(e,p).addOnSuccessListener { adminMode = true; seedDefaultsThenOpen() }
                    .addOnFailureListener { toast("Login failed: ${it.localizedMessage}") }
            }
        })
        card("Admin account setup", "Firebase Console में Authentication → Email/Password enable करके अपना admin account बनाएं।")
    }

    private fun seedDefaultsThenOpen() {
        db.collection("services").get().addOnSuccessListener { snapshot ->
            if (!snapshot.isEmpty) { showAdminPanel(); return@addOnSuccessListener }
            val batch = db.batch()
            fallback.forEach { item ->
                val ref = db.collection("services").document(item.id)
                batch.set(ref, mapOf("titleHi" to item.titleHi, "titleEn" to item.titleEn, "price" to item.price, "category" to item.category))
            }
            batch.commit().addOnSuccessListener { showAdminPanel() }.addOnFailureListener { toast(it.localizedMessage ?: "Could not initialize services") }
        }.addOnFailureListener { toast(it.localizedMessage ?: "Could not load services") }
    }

    private fun showAdminPanel() {
        if (!adminMode || auth.currentUser == null) { showAdminLogin(); return }
        base("Manage Rates")
        content.addView(button("← Home", navy).apply { setOnClickListener { auth.signOut(); adminMode=false; showHome() } })
        sectionTitle("Manage Services & Rates / रेट बदलें")
        content.addView(button("+ Add New Service / नई सेवा जोड़ें", gold, ink).apply { setOnClickListener { editService(null) } })
        services.forEach { item ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,12,12,12); setBackgroundColor(Color.WHITE) }
            row.addView(TextView(this).apply { text = "${item.titleHi} | ${item.titleEn}\n${item.price}"; textSize=15f; setTextColor(ink) })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(button("Edit", blue).apply { setOnClickListener { editService(item) } }, LinearLayout.LayoutParams(0,-2,1f))
            actions.addView(button("Delete", Color.rgb(180,45,45)).apply { setOnClickListener { db.collection("services").document(item.id).delete().addOnSuccessListener { toast("Deleted") }.addOnFailureListener { toast(it.localizedMessage ?: "Error") } } }, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(actions); content.addView(row, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 })
        }
    }

    private fun editService(old: ShopService?) {
        val panel = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(8,4,8,4) }
        val hi = EditText(this).apply { hint="सेवा का नाम (Hindi)"; setText(old?.titleHi ?: "") }
        val en = EditText(this).apply { hint="Service name (English)"; setText(old?.titleEn ?: "") }
        val price = EditText(this).apply { hint="Price / रेट (e.g. ₹10)"; setText(old?.price ?: "") }
        val category = EditText(this).apply { hint="Category: Printing, Photo, Online Services, Stationery & Gifts"; setText(old?.category ?: "Online Services") }
        panel.addView(hi); panel.addView(en); panel.addView(price); panel.addView(category)
        AlertDialog.Builder(this).setTitle(if(old==null) "Add Service" else "Edit Service").setView(panel)
            .setPositiveButton("Save") { _, _ ->
                val id = old?.id ?: db.collection("services").document().id
                val data = hashMapOf("titleHi" to hi.text.toString(), "titleEn" to en.text.toString(), "price" to price.text.toString(), "category" to category.text.toString())
                if (data.values.any { it.isBlank() }) { toast("सभी जानकारी भरें"); return@setPositiveButton }
                db.collection("services").document(id).set(data).addOnSuccessListener { toast("Saved successfully"); showAdminPanel() }.addOnFailureListener { toast(it.localizedMessage ?: "Save failed") }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun listenForRates() {
        listener = db.collection("services").addSnapshotListener { snapshot, error ->
            if (error != null || snapshot == null || snapshot.isEmpty) return@addSnapshotListener
            services = snapshot.documents.mapNotNull { d ->
                val hi=d.getString("titleHi") ?: return@mapNotNull null
                val en=d.getString("titleEn") ?: ""
                ShopService(d.id,hi,en,d.getString("price") ?: "Contact",d.getString("category") ?: "Online Services")
            }.toMutableList()
            if (adminMode && auth.currentUser != null) showAdminPanel()
        }
    }

    private fun card(title: String, body: String) {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,15,16,15); setBackgroundColor(Color.WHITE) }
        box.addView(TextView(this).apply { text=title; textSize=18f; setTextColor(navy); setTypeface(null,1) })
        box.addView(TextView(this).apply { text=body; textSize=14f; setTextColor(ink); setPadding(0,7,0,0) })
        content.addView(box, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=14 })
    }
    private fun sectionTitle(s:String) { content.addView(TextView(this).apply { text=s; textSize=20f; setTextColor(navy); setTypeface(null,1); setPadding(2,12,2,10) }) }
    private fun button(s:String, color:Int, textColor:Int=Color.WHITE) = Button(this).apply { text=s; isAllCaps=false; setTextColor(textColor); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); textSize=14f; setPadding(8,8,8,8) }
    private fun categoryLabel(s:String) = when(s) { "Printing"->"Printing / प्रिंटिंग"; "Photo"->"Photo Services / फोटो सेवा"; "Online Services"->"Online Services / ऑनलाइन सेवाएँ"; else->"Stationery & Gifts / स्टेशनरी एवं गिफ्ट" }
    private fun openWhatsApp() { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/919693952498?text="+Uri.encode("Namaste, mujhe aapki services ki jankari chahiye.")))) } catch (_:Exception) { toast("WhatsApp not available") } }
    private fun openMap() { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+Uri.encode("Gauri Stationery & Online Services, Barwal, Narwal, Near Kali Mandir, Bagaha, Bihar 845105")))) }
    private fun toast(s:String?) { Toast.makeText(this, s ?: "Something went wrong", Toast.LENGTH_LONG).show() }
}
